import java.util.List;

public class DanceGroup {

	private List<String> pupils;
	private String category;
	
	public List<String> getPupils() {
		return pupils;
	}
	public void setPupils(List<String> pupils) {
		this.pupils = pupils;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
}
