import java.util.List;

public class Dance {

	
	private int no;
	private String customDesign;
	private List<DanceGroup> dancegroup;
	
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getCustomDesign() {
		return customDesign;
	}
	public void setCustomDesign(String customDesign) {
		this.customDesign = customDesign;
	}
	public List<DanceGroup> getDancegroup() {
		return dancegroup;
	}
	public void setDancegroup(List<DanceGroup> dancegroup) {
		this.dancegroup = dancegroup;
	}

	
	//private String name;
}
