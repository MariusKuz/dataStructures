import java.util.List;

public class DanceShow {

	private List<Dance> dances;

	public List<Dance> getDances() {
		return dances;
	}

	public void setDances(List<Dance> dances) {
		this.dances = dances;
	}
}
